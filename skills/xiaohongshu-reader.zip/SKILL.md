---
name: xiaohongshu-reader
description: 读取小红书笔记内容（文字+图片），绕过反爬机制
trigger: 用户发送 xhslink.com 短链接或 xiaohongshu.com 笔记链接时触发
tools:
  - terminal
  - vision
---

# 小红书笔记抓取（文字 + 图片）

小红书对非移动端浏览器和服务器 IP 有严格的反爬机制，浏览器直接访问会被拦到"安全限制"页面。

## 核心原理：为什么这个方法有效

小红书短链接的访问场景是**社交分享预览**——用户复制链接发到微信/QQ，这些平台会先抓取页面的 og:title、og:description、og:image 来生成预览卡片。所以短链接被访问时，小红书服务端**必须**做 SSR（Server-Side Rendering）把内容注入 HTML，否则分享预览就是空白的。

- **短链接 + 移动端 UA** → 触发分享预览逻辑 → 服务端渲染 → 内容完整注入到 `__INITIAL_STATE__` JSON
- **长链接 + 桌面 UA** → 走 SPA（单页应用）路线 → 内容靠前端 JS 动态加载 → 拿不到

只要短链接分享功能在，这个口子就不会堵上。不是"伪装客户端"，是利用了小红书分享功能的必需设计。

## 完整流程（三步：抓文字 → 下载图片 → 识别图片）

全部在 `execute_code` 中完成，一次性跑完。

### 第一步：抓取文字内容

```python
from hermes_tools import terminal
import re

url = "http://xhslink.com/o/XXXXXX"  # 用户给的短链接

result = terminal(f"""curl -s -L '{url}' \
  -H 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1' \
  -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' \
  -H 'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8' \
  --compressed""", timeout=15)

html = result.get("output", "")

# ⚠️ 不要用 re.search(r'"title":"([^"]*)"', html) 盲取第一个匹配！
# HTML 中有大量推荐流/热搜的 title，第一个匹配大概率不是目标笔记。
# 正确方式：用用户消息中的标题关键词或笔记 ID 精确定位。

# 方法A：用标题关键词定位（用户分享文案中通常包含标题）
keyword = "用户消息中的标题片段"  # 从用户消息提取
pos = html.find(f'"title":"{keyword}')
if pos >= 0:
    # 从 title 往后找 desc
    desc_start = html.find('"desc":"', pos)
    desc_start += len('"desc":"')
    end = desc_start
    while end < len(html):
        if html[end] == '"' and html[end-1] != '\\':
            break
        end += 1
    desc = html[desc_start:end]
else:
    desc = "未找到正文"

# 方法B：如果知道笔记ID，用 imageList 定位
# note_id = "69edb477000000003803599f"
# pos = html.find(note_id)

desc = desc.replace('\\n', '\n').replace('\\t', '\t').replace('\\u002F', '/')
print(f"正文:\n{desc}")
```

### 第二步：下载图片

```python
# imageList 在 title 附近，提取所有图片 URL
# 每张图有 2 种格式：h5_1080jpg（原图）和 style_xxx（缩略图），取 h5_1080jpg
img_area_start = html.find('"imageList":[')
bracket_start = html.index('[', img_area_start)
depth = 0
bracket_end = bracket_start
for i in range(bracket_start, min(bracket_start + 10000, len(html))):
    if html[i] == '[': depth += 1
    elif html[i] == ']':
        depth -= 1
        if depth == 0:
            bracket_end = i + 1
            break

img_json_str = html[bracket_start:bracket_end].replace('\\u002F', '/')

# 提取 h5_1080jpg 格式的 URL（原图）
img_urls = re.findall(r'"url":"(http[^"]*h5_1080jpg)"', img_json_str)
# 如果没有 h5_1080jpg，取所有 URL 然后去重
if not img_urls:
    img_urls = list(dict.fromkeys(re.findall(r'"url":"(http[^"]+)"', img_json_str)))

# 下载图片到 /tmp
for i, u in enumerate(img_urls):
    terminal(f"curl -sL -o /tmp/xhs_img_{i}.jpg '{u}'", timeout=10)

print(f"共 {len(img_urls)} 张图片已下载到 /tmp/xhs_img_0.jpg ~ /tmp/xhs_img_{len(img_urls)-1}.jpg")
```

### 第三步：识别图片内容（可选）

```python
# 用 vision_analyze 识别图片内容
# 适合图文笔记（笔记正文只有摘要，详细信息在图片中）
from hermes_tools import vision_analyze

for i in range(len(img_urls)):
    result = vision_analyze(
        image_url=f"/tmp/xhs_img_{i}.jpg",
        question="请详细描述这张小红书笔记图片的全部内容，包括所有文字。"
    )
    print(f"\n=== 图{i+1} ===")
    print(result.get("analysis", ""))
```

### 发送图片给用户

在回复中使用 `M-E-D-I-A:/tmp/xhs_img_0.jpg` 格式逐张发送（实际使用时去掉连字符，即 M+EDIA）。
每张图一行，飞书网关会自动上传并展示。

## 如果用户给的是长链接

用户有时发的是 `https://www.xiaohongshu.com/explore/{noteId}` 长链接，无法直接触发 SSR：

```python
# 从长链接提取 noteId
note_match = re.search(r'xiaohongshu\.com/explore/([a-f0-9]+)', url)
if note_match:
    note_id = note_match.group(1)
    # 方案1：直接用长链接 + iPhone UA 尝试（成功率较低，可能返回空内容）
    # 方案2：告知用户"请复制短链接分享"（短链接在小红书APP内点分享→复制链接获取）
```

**长链接成功率远低于短链接，优先让用户提供短链接。**

## 风控说明

- 整个链路对小红书服务器只有 1 次页面请求 + N 次图片下载，量级在正常用户范围内
- 图片 CDN（sns-webpic-qc.xhscdn.com）通常不做严格反爬校验
- vision_analyze 是本地 AI 分析，不接触小红书服务器
- **不会触发风控**，但也要避免短时间内批量抓取几十篇笔记

## 失败的方案（不要用）

- ❌ `browser_navigate` 直接打开 → "IP at risk" 安全限制页
- ❌ curl + 桌面浏览器 UA → SPA 模式，`noteData.data` 为空
- ❌ `re.search(r'"title":"([^"]*)"', html)` 取第一个 title → 匹配到推荐流的其他笔记
- ❌ 小红书 Web API (`edith.xiaohongshu.com/api/sns/web/v1/feed`) → 需要签名 token
- ❌ 搜索引擎缓存 → 通常索引不到小红书笔记全文

## 注意事项

- 短链接有时效性，过久可能失效，尽量即时抓取
- 话题标签格式为 `#话题名[话题]#`，可做清理
- 笔记内容中的表情用 `[表情名]` 格式，如 `[扯脸H]`、`[嘻嘻R]`
- 图文笔记的关键信息往往在图片里而不在 desc 中，务必下载图片识别
- 图片下载用的是 HTTP CDN 链接，不需要特殊处理
