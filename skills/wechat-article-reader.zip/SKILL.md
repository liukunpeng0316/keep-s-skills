---
name: wechat-article-reader
description: 读取微信公众号文章内容，绕过环境检测验证
trigger: 用户发送 mp.weixin.qq.com 链接时触发
tools:
  - terminal
---

# 微信公众号文章抓取

微信公众平台会对浏览器访问做环境检测，但 curl + 伪装 User-Agent 可以绕过。

## 快速使用（推荐方式：execute_code）

用 execute_code 调用，分两步：curl 抓取 + Python 提取。

```python
import re

# Step 1: curl 抓取（用微信客户端 UA 绕过反爬）
import subprocess
result = subprocess.run([
    'curl', '-sL',
    '-H', 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.43(0x18002b2f) NetType/WIFI Language/zh_CN',
    '-H', 'Accept: text/html,application/xhtml+xml',
    '-H', 'Accept-Language: zh-CN,zh;q=0.9',
    '-o', '/tmp/wx_article.html',
    '文章URL'
], capture_output=True, text=True)

# Step 2: Python 提取标题和正文
with open('/tmp/wx_article.html', 'r', errors='ignore') as f:
    html = f.read()

# 标题（msg_title 变量最可靠）
title_m = re.search(r'var msg_title\s*=\s*["\x27](.*?)["\x27]', html)
title = title_m.group(1) if title_m else re.search(r'<title>(.*?)</title>', html).group(1)

# 正文（js_content 区域，注意 style 可能设 visibility:hidden）
start = html.find('id="js_content"')
end = html.find('id="js_pc_close_btn"', start) if start > 0 else -1
if end < 0:
    end = start + 50000
content_html = html[start:end] if start > 0 else ""
text = re.sub(r'<[^>]+>', '\n', content_html)
text = re.sub(r'&nbsp;', ' ', text)
text = re.sub(r'\n{3,}', '\n\n', text).strip()

print(f"标题: {title}")
print(f"正文:\n{text[:3000]}")
```

## 关键原理

1. **必须用微信客户端 UA**（MicroMessenger），普通浏览器 UA 会被拦截到验证页面
2. 微信公众号文章真实内容在 `<div id="js_content">` 中，但设了 `visibility: hidden`
3. **浏览器访问反而会被拦**（环境异常验证），curl 才能绕过
4. 标题优先从 `var msg_title` JS 变量提取，比 `<title>` 标签更可靠

## 陷阱

- ❌ browser_navigate 打开微信文章 → 触发「环境异常」验证页
- ❌ Windows Chrome UA → 也会被拦
- ✅ iPhone + MicroMessenger UA → 成功绕过
- 正文可能很大（几MB），建议只取前 2000-3000 字做摘要
- 付费文章可能无法读取完整内容
